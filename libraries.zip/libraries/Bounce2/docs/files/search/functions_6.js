var searchData=
[
  ['pressed',['pressed',['../class_button.html#a8e37fb754907685539ea71183204b033',1,'Button']]],
  ['previousduration',['previousDuration',['../class_debouncer.html#a89ab95e7ac24874bb8cb684dc36a98b9',1,'Debouncer']]]
];
